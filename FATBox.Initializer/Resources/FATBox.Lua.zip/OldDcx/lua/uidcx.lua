

function GoThread()
	
	import('/lua/instr.lua')

	
    #local econData = GetEconomyTotals()
	#local xxx = econData["income"]["MASS"]
	#LOG(repr(xxx))
end
