doscript '/dumpBlueprints.lua'
